package net.phoenix.phoenix_fission.api.machine.multiblock.managers;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.util.StringRepresentable;
import net.phoenix.phoenix_fission.api.PhoenixAPI;
import net.phoenix.phoenix_fission.api.block.iface.*;
import net.phoenix.phoenix_fission.api.machine.multiblock.FissionWorkableElectricMultiblockMachine;

import lombok.Getter;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FissionComponentManager {

    private final FissionWorkableElectricMultiblockMachine machine;

    @Getter
    protected final List<IFissionCoolerType> activeCoolers = new ArrayList<>();
    @Getter
    protected final List<IFissionModeratorType> activeModerators = new ArrayList<>();
    @Getter
    protected final List<IFissionFuelRodType> activeFuelRods = new ArrayList<>();
    @Getter
    protected final List<IFissionBlanketType> activeBlankets = new ArrayList<>();
    @Getter
    protected final List<IFissionStabilityHatchType> activeStabilityHatches = new ArrayList<>();
    @Getter
    protected final List<IFissionSensorHatchType> activeSensorHatches = new ArrayList<>();

    @Nullable
    @Getter
    protected IFissionCoolerType primaryCoolerType = null;
    @Nullable
    @Getter
    protected IFissionModeratorType primaryModeratorType = null;
    @Nullable
    @Getter
    protected IFissionFuelRodType primaryFuelRodType = null;

    public FissionComponentManager(FissionWorkableElectricMultiblockMachine machine) {
        this.machine = machine;
    }

    public void onStructureFormed() {
        this.activeCoolers.addAll(getListFromContext("CoolerTypes"));
        this.activeModerators.addAll(getListFromContext("ModeratorTypes"));
        this.activeFuelRods.addAll(getListFromContext("FuelRodTypes"));
        this.activeBlankets.addAll(getListFromContext("BlanketTypes"));
        this.activeStabilityHatches.addAll(getListFromContext("StabilityTypes"));
        this.activeSensorHatches.addAll(getListFromContext("SensorTypes"));

        machine.getPersistedCoolerIDs().clear();
        machine.getPersistedCoolerIDs().addAll(this.activeCoolers.stream().map(IFissionCoolerType::getName).toList());
        machine.getPersistedModeratorIDs().clear();
        machine.getPersistedModeratorIDs()
                .addAll(this.activeModerators.stream().map(IFissionModeratorType::getName).toList());
        machine.getPersistedFuelRodIDs().clear();
        machine.getPersistedFuelRodIDs()
                .addAll(this.activeFuelRods.stream().map(IFissionFuelRodType::getName).toList());
        machine.getPersistedBlanketIDs().clear();
        machine.getPersistedBlanketIDs()
                .addAll(this.activeBlankets.stream().map(IFissionBlanketType::getName).toList());
        machine.getPersistedStabilityIDs().clear();
        machine.getPersistedStabilityIDs()
                .addAll(this.activeStabilityHatches.stream().map(IFissionStabilityHatchType::getName).toList());
        machine.getPersistedSensorIDs().clear();
        machine.getPersistedSensorIDs()
                .addAll(this.activeSensorHatches.stream().map(IFissionSensorHatchType::getName).toList());

        recalcPrimaries();
    }

    public void onStructureInvalid() {
        activeCoolers.clear();
        activeModerators.clear();
        activeFuelRods.clear();
        activeBlankets.clear();
        activeStabilityHatches.clear();
        activeSensorHatches.clear();

        machine.getPersistedCoolerIDs().clear();
        machine.getPersistedModeratorIDs().clear();
        machine.getPersistedFuelRodIDs().clear();
        machine.getPersistedBlanketIDs().clear();
        machine.getPersistedStabilityIDs().clear();
        machine.getPersistedSensorIDs().clear();

        primaryCoolerType = null;
        primaryModeratorType = null;
        primaryFuelRodType = null;
    }

    public void resolvePersistedComponents() {
        // Rebuilds the active-component lists from the persisted IDs - deliberately does NOT
        // call onStructureInvalid(), which also clears machine's persisted ID lists themselves.
        // Doing that here would wipe out real data loaded from NBT (or already synced to the
        // client) an instant before the loop below tries to read it back, since the lists are
        // cleared in place rather than replaced - e.g. on a fresh onLoad() for a reactor that was
        // already formed before a chunk unload/server restart, silently losing every fuel
        // rod/cooler/moderator until the pattern happens to be re-checked and reformed.
        activeCoolers.clear();
        activeModerators.clear();
        activeFuelRods.clear();
        activeBlankets.clear();
        activeStabilityHatches.clear();
        activeSensorHatches.clear();
        primaryCoolerType = null;
        primaryModeratorType = null;
        primaryFuelRodType = null;

        for (String id : machine.getPersistedCoolerIDs()) {
            PhoenixAPI.FISSION_COOLERS.keySet().stream().filter(t -> t.getName().equals(id)).findFirst()
                    .ifPresent(activeCoolers::add);
        }
        for (String id : machine.getPersistedModeratorIDs()) {
            PhoenixAPI.FISSION_MODERATORS.keySet().stream().filter(t -> t.getName().equals(id)).findFirst()
                    .ifPresent(activeModerators::add);
        }
        for (String id : machine.getPersistedFuelRodIDs()) {
            PhoenixAPI.FISSION_FUEL_RODS.keySet().stream().filter(t -> t.getName().equals(id)).findFirst()
                    .ifPresent(activeFuelRods::add);
        }
        for (String id : machine.getPersistedBlanketIDs()) {
            PhoenixAPI.FISSION_BLANKETS.keySet().stream().filter(t -> t.getName().equals(id)).findFirst()
                    .ifPresent(activeBlankets::add);
        }
        for (String id : machine.getPersistedStabilityIDs()) {
            PhoenixAPI.FISSION_STABILITY_HATCHES.keySet().stream().filter(t -> t.getName().equals(id)).findFirst()
                    .ifPresent(activeStabilityHatches::add);
        }
        for (String id : machine.getPersistedSensorIDs()) {
            PhoenixAPI.FISSION_SENSOR_HATCHES.keySet().stream().filter(t -> t.getName().equals(id)).findFirst()
                    .ifPresent(activeSensorHatches::add);
        }
        recalcPrimaries();
    }

    private void recalcPrimaries() {
        this.primaryCoolerType = calcPrimary(activeCoolers);
        this.primaryModeratorType = calcPrimary(activeModerators);
        this.primaryFuelRodType = calcPrimary(activeFuelRods);
    }

    private <T extends StringRepresentable> @Nullable T calcPrimary(List<T> list) {
        if (list.isEmpty()) return null;
        return list.stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream()
                .max(Comparator.<Map.Entry<T, Long>>comparingLong(Map.Entry::getValue))
                .map(Map.Entry::getKey).orElse(null);
    }

    @SuppressWarnings("unchecked")
    private <T> List<T> getListFromContext(String key) {
        Object obj = machine.getMultiblockState().getMatchContext().get(key);
        if (obj instanceof List<?> list) return (List<T>) list;
        return new ArrayList<>();
    }

    public void addDisplayText(List<Component> textList) {
        addBreakdown(textList, activeFuelRods, "Fuel Rods");
        addBreakdown(textList, activeModerators, "Moderators");
        addBreakdown(textList, activeCoolers, "Coolers");
    }

    private <T extends StringRepresentable> void addBreakdown(List<Component> textList, List<T> components,
                                                              String header) {
        textList.add(Component.literal(header + " (" + components.size() + "):").withStyle(ChatFormatting.AQUA));
        if (components.isEmpty()) {
            textList.add(Component.literal("  None").withStyle(ChatFormatting.DARK_GRAY));
            return;
        }
        components.stream()
                .collect(Collectors.groupingBy(T::getSerializedName, LinkedHashMap::new, Collectors.counting()))
                .forEach((name, count) -> textList.add(Component.literal("  ")
                        .append(Component.translatable("phoenix_fission." + name).withStyle(ChatFormatting.YELLOW))
                        .append(Component.literal(" x" + count).withStyle(ChatFormatting.GRAY))));
    }
}
